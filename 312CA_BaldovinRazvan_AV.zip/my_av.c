// Copyright Baldovin Razvan-Mihai-Marian 312CA 2023
#include <stdio.h>

#include "traffic_check.h"
#include "url_check.h"

int main(void)
{
	url_av();
	traffic_av();
	return 0;
}

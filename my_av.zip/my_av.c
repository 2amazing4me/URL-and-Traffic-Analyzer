#include <stdio.h>

#include "traffic_check.h"
#include "url_check.h"

int main(void)
{
	url_av();
	traffic_av();
	return 0;
}
